
// Configure the back link on the page
let backOption = document.querySelector(".back-option");
backOption.setAttribute("href", document.referrer);